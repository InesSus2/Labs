/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uv.eu.euroconversor.view;

import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author EU (2016)
 */

public class EuroConversorMenu extends JMenuBar{
    private JMenu menu;
    private JMenuItem exit;
    private JMenuItem changeRate;

    public EuroConversorMenu(){
        menu = new JMenu("EuroConversor");
        exit = new JMenuItem("Salir");
        changeRate = new JMenuItem("Cambiar tasa de cambio");
        exit.setActionCommand("Exit");
        changeRate.setActionCommand("ChangeRate");
        menu.add(changeRate);
        menu.add(exit);
        this.add(menu);
        
        this.setVisible(true);
    }

    public void setActionListener(ActionListener actionListener){
        exit.addActionListener(actionListener);
        changeRate.addActionListener(actionListener);
    }
}