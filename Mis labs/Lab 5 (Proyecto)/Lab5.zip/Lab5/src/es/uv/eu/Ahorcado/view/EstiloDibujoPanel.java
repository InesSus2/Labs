package es.uv.eu.Ahorcado.view;

import javax.swing.BoxLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/*********************************************************************
 * @author Inés Jaso Pernod
 * @author Natalia Tauste Rubio
 ********************************************************************/

public class EstiloDibujoPanel extends JPanel{
    private JLabel texto;
    private JComboBox<String> CBEstiloDibujo;
    private String[] estilos = {"Clásico", "Peluche", "Hello Kitty"};

    public EstiloDibujoPanel() {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setBackground(Color.WHITE);
        
        texto = new JLabel("ESTILO DEL DIBUJO:");
        CBEstiloDibujo = new JComboBox<>(estilos);
        CBEstiloDibujo.setMaximumSize(new Dimension(150, 20));

        CBEstiloDibujo.setActionCommand("EstilosDibujo");

        texto.setAlignmentX(Component.CENTER_ALIGNMENT);
        CBEstiloDibujo.setAlignmentX(Component.CENTER_ALIGNMENT);

        this.add(texto);
        this.add(CBEstiloDibujo);

        this.setVisible(true);
    }

    /************************* getEstiloDibujo() *************************
     * @brief Getter para el estilo del dibujo seleccionado
     * 
     * @return Estilo del dibujo seleccionado
     ********************************************************************/
    public String getEstiloDibujo() {
        return (String) CBEstiloDibujo.getSelectedItem();
    }

    /*************************** setSelectedItem() ***********************
     * @brief Setter del estilo del dibujo seleccionado
     * 
     * @param string Estilo del dibujo a seleccionar
     ********************************************************************/
    public void setSelectedItem(String string) {
        CBEstiloDibujo.setSelectedItem(string);
    }

    /************************ setActionListener() *************************
     * @brief Asigna un ActionListener a todos los elementos del panel
     * 
     * @param actionListener ActionListener a asignar
     ********************************************************************/
    public void setActionListener(ActionListener actionListener){
        CBEstiloDibujo.addActionListener(actionListener);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Prueba EstiloDibujoPanel");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 300);
            frame.add(new EstiloDibujoPanel());
            
            frame.setVisible(true);
        });
    }
}