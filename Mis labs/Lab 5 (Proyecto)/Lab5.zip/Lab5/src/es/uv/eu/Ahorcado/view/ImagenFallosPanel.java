package es.uv.eu.Ahorcado.view;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import es.uv.eu.Ahorcado.model.AhorcadoModel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

/*********************************************************************
 * @author Inés Jaso Pernod
 * @author Natalia Tauste Rubio
 ********************************************************************/

public class ImagenFallosPanel extends JPanel {

    private AhorcadoModel modelo;
    private Border borde;

    public ImagenFallosPanel(AhorcadoModel modelo) {
        this.modelo = modelo;

        this.setLayout(new FlowLayout());
        this.setBackground(Color.WHITE);

        borde = BorderFactory.createLineBorder(Color.BLACK, 1);
        this.setBorder(borde);

        this.setPreferredSize(new Dimension(150, 150));
        this.setVisible(true);
    }

    /**************************** setModelo() ****************************
     * @brief Método para actualizar el modelo
     * (cuando se cambia de palabra o estilo)
     * 
     * @param nuevoModelo Nuevo modelo a asignar
     ********************************************************************/
    public void setModelo(AhorcadoModel nuevoModelo) {
        this.modelo = nuevoModelo;
        repaint();  ///< Forzar repintado con el nuevo modelo
    }

    /************************* actualizarImagen() ************************
     * @brief Método para forzar la actualización de la imagen
     ********************************************************************/
    public void actualizarImagen() {
        System.out.println("ImagenFallosPanel: Solicitando repintado...");
         ///< Forzar repintado en el hilo de Swing
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                repaint();
                revalidate();
            }
        });
    }

    /************************* paintComponent() **************************
     * @brief Método para pintar la imagen del ahorcado
     * 
     * @param g Objeto Graphics para pintar
     ********************************************************************/
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        System.out.println("ImagenFallosPanel: Repintando componente...");
        
        if (modelo != null) {
            BufferedImage imagen = modelo.getImagenAhorcado();
            if (imagen != null) {
                System.out.println("ImagenFallosPanel: Dibujando imagen de tamaño " + imagen.getWidth() + "x" + imagen.getHeight());
                g.drawImage(
                    imagen,
                    0,
                    0,
                    this.getWidth(),
                    this.getHeight(),
                    null
                );
            } else {
                System.out.println("ImagenFallosPanel: La imagen es NULL");
                ///< Dibujar un mensaje de error
                g.setColor(Color.RED);
                g.drawString("No hay imagen", 10, 50);
            }
        } else {
            System.out.println("ImagenFallosPanel: El modelo es NULL");
            g.setColor(Color.RED);
            g.drawString("No hay modelo", 10, 50);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Prueba ImagenFallosPanel");
            AhorcadoModel modelo = new AhorcadoModel(); ///< Constructor sin parámetros

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 600);
            frame.add(new ImagenFallosPanel(modelo));
            frame.setVisible(true);
        });
    }
}