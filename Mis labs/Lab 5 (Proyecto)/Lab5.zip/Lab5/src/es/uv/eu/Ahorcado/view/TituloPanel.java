package es.uv.eu.Ahorcado.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

/*********************************************************************
 * @author Inés Jaso Pernod
 * @author Natalia Tauste Rubio
 ********************************************************************/

public class TituloPanel extends JPanel {
    private JLabel titulo;
    public TituloPanel() {
        this.setBackground(Color.WHITE);
        titulo = new JLabel("EL JUEGO DEL AHORCADO");

        titulo = new JLabel("EL JUEGO DEL AHORCADO", SwingConstants.CENTER);

        titulo.setFont(new Font("SansSerif", Font.BOLD, 32)); ///< Hemos escogido este tipo de letra
        titulo.setForeground(new Color(60, 60, 60)); ///< Gris oscuro
        titulo.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10)); ///< Sin borde
        this.add(titulo, BorderLayout.CENTER);

        this.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Prueba TituloPanel");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 600);
            frame.add(new TituloPanel());
            
            frame.setVisible(true);
        });
    }
}